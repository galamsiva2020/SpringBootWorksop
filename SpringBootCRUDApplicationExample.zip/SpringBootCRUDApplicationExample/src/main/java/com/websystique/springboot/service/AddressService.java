package com.websystique.springboot.service;


import com.websystique.springboot.model.Address;
import com.websystique.springboot.model.User;

import java.util.List;

public interface AddressService {
	
	Address findById(Long id);

	Address findByName(String name);

	void saveUser(Address user);

	void updateUser(Address user);

	void deleteUserById(Long id);

	void deleteAllUsers();

	List<Address> findAllUsers();

	boolean isUserExist(Address user);
}