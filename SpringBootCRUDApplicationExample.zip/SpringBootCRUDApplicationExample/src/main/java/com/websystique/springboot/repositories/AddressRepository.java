package com.websystique.springboot.repositories;

import com.websystique.springboot.model.Address;
import com.websystique.springboot.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AddressRepository extends JpaRepository<Address, Long> {

    Address findByName(String name);

}
