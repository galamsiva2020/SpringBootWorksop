package com.websystique.springboot.service;

import com.websystique.springboot.model.Address;
import com.websystique.springboot.model.User;
import com.websystique.springboot.repositories.AddressRepository;
import com.websystique.springboot.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Service("addressService")
@Transactional
public class AddressServiceImpl implements AddressService{

	@Autowired
	private AddressRepository userRepository;

	public Address findById(Long id) {
		return userRepository.findOne(id);
	}

	public Address findByName(String name) {
		return userRepository.findByName(name);
	}

	public void saveUser(Address user) {
		userRepository.save(user);
	}

	public void updateUser(Address user){
		saveUser(user);
	}

	public void deleteUserById(Long id){
		userRepository.delete(id);
	}

	public void deleteAllUsers(){
		userRepository.deleteAll();
	}

	public List<Address> findAllUsers(){
		return userRepository.findAll();
	}

	public boolean isUserExist(Address user) {
		return findByName(user.getName()) != null;
	}

}
